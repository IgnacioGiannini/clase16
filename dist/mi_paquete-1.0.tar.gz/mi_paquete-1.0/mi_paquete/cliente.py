class Cliente:
    def __init__(self, n, e, c, d):
        self.nombre = n
        self.edad = e
        self.direccion = d
        self.correo = c

    def comprar(self, producto):
        print(f"{self.nombre} compro {producto}.")

    def enviar_correo(self, mensaje):
        print(f"Correo enviado a {self.nombre}: {mensaje}")

    def __str__(self):
        return f"Cliente: {self.nombre}"

#clientes
cliente1 = Cliente("ana", 18, "Calle 123, Ciudad", "ana@ejemplo.com")
cliente2 = Cliente("nacho", 19, "Avenida 456, Ciudad", "nacho@ejemplo.com")

print(cliente1.nombre)  # Imprimirá "ana"
print(cliente2.edad)  # Imprimirá 19

cliente1.comprar("telefono")  # Imprimirá "ana compro telefono."
cliente2.enviar_correo("Hola nacho. ¡Gracias por tu compra!")  # Imprimirá "Correo enviado a nacho: Hola, nacho. ¡Gracias por tu compra!"